/**
 * Project 5
 * @author Kush Rustagi, krustagi, 806
 * @author Eehita Parameswaran, eparames, LN1 (810)
 */
import java.util.*;
import java.io.*;
import java.net.*;
public class SafeWalkServer implements Runnable{
    static int port = 8888; 
    List<People> list = new ArrayList<People>();
    String arr[] = new String[]{"CL50","EE","LWSN","PMU","PUSH","*"};
    public SafeWalkServer(int port) throws SocketException, IOException {
        this.port = port;
    }
    public SafeWalkServer() throws SocketException, IOException {
    }
    public int getLocalPort() { return port; }
    public void run() {
        try {
            ServerSocket ss = new ServerSocket(port);
            while (true) {
                Socket client = ss.accept();
                InputStreamReader stream = new InputStreamReader(client.getInputStream());
                BufferedReader reader = new BufferedReader(stream);
                String s2 = reader.readLine();
                if (confirm(s2) == false) { YoloPrint("ERROR: invalid request", client); }
                else {
                    if ((s2.charAt(0) + "").equals(":")) { //command
                        if (s2.equals(":LIST_PENDING_REQUESTS")) {
                            String all = "";
                            all += "[";
                            for (int i = 0; i < list.size() - 1; i++) {
                                all += "["+list.get(i).name+", "+list.get(i).from+", "+list.get(i).to+", "+list.get(i).type+ "], ";
                            }
                            all += "[" + list.get(list.size() - 1).name+", "+list.get(list.size() - 1).from+", "+list.get(list.size() - 1).to+", "+list.get(list.size() - 1
                                                                                                                                                           ).type + "]]";
                            YoloPrint(all, client);
                        }
                        else if (s2.equals(":RESET")) {
                            for (int i = 0; i < list.size(); i++) {
                                YoloPrint("ERROR: connection reset", list.get(i).so);
                            }
                            YoloPrint("RESPONSE: success", client);
                            list.clear();
                        }
                        else if (s2.equals(":SHUTDOWN")) {
                            for (int i = 0; i < list.size(); i++) {
                                YoloPrint("ERROR: connection reset", list.get(i).so);
                            }
                            YoloPrint("RESPONSE: success", client);
                            list.clear();
                            reader.close();
                            stream.close();
                            ss.close();
                            break;
                        }
                    }
                    else { //request
                        list.add(new People(s2, client));
                        if (list.size() > 1) { 
                            String from = list.get(list.size() - 1).from;
                            String to = list.get(list.size() - 1).to;
                            for (int i = 0; i < list.size() - 1; i++) {
                                if (list.get(i).from.equals(from)) {
                                    if (list.get(i).to.equals("*") && to.equals("*")) { }
                                    else if (list.get(i).to.equals(to) || to.equals("*") || list.get(i).to.equals("*")) {
                                        YoloPrint("RESPONSE: " + list.get(i).st, list.get(list.size() - 1).so);
                                        YoloPrint("RESPONSE: " + list.get(list.size() - 1).st, list.get(i).so);
                                        list.remove(i);
                                        list.remove(list.size() - 1);
                                    }
                                }
                            } // end of for
                        }
                    }
                }
            }
        }
        catch (Exception e) {
        }
    }
    public void YoloPrint(String m, Socket client) throws Exception{
        PrintWriter p = new PrintWriter(client.getOutputStream(),true);
        p.println(m);
        p.close();
        client.close();
    }
    public boolean confirm(String s) {
        if ((s.charAt(0) + "").equals(":")) {//command
            if (s.equals(":LIST_PENDING_REQUESTS") || s.equals(":RESET") || s.equals(":SHUTDOWN")) { 
                return true;
            }
            else return false;
        }
        else { //request msg
            int c = 0;
            int i = 0;
            for (int k = 0; k < s.length(); k++) {
                if ((s.charAt(k) + "").equals(","))
                    c++;
            }
            if (c != 3) { return false; }
            Scanner sc = new Scanner(s);
            sc.useDelimiter(",");
            String str = "";
            while (sc.hasNext()) {
                String st = sc.next();
                if (i == 1) {                                                                                                                                               
                    str = st;
                    c = 0;
                    for (int j = 0; j < arr.length; j++) {
                        if (st.equals(arr[j])) 
                            c++;
                    }
                    if (c == 0 || st.equals("*")) { return false; }
                }
                else if (i == 2) {
                    c = 0;
                    for (int j = 0; j < arr.length; j++) {
                        if (st.equals(arr[j])) 
                            c++;
                    }
                    if (c == 0 || st.equals(str)) { return false; }
                }
                i++;
            }
        }
        return true;
    }
    public static void main(String[] args) throws Exception {
        if (args.length == 0) { 
            System.out.println ("Port not specified. Using free port 8888.");
            SafeWalkServer s = new SafeWalkServer(port);
            s.run();
        }
        else {
            if (port < 1025 && port > 65535) {
                System.out.println ("Error");
            }
            else { SafeWalkServer s = new SafeWalkServer(port);
                s.run();
            }
        }
    }
}
class People {
    Socket so;
    public String name;
    public String from;
    public String to;
    public int type = 0;
    public String st = "";
    int i = 0;
    public People(String s, Socket socket) {
        so = socket;
        st = s;
        Scanner sc = new Scanner(s);
        sc.useDelimiter(",");
        while (sc.hasNext()) {
            String st = sc.next();
            if (i == 0) { name = st; }
            else if (i == 1) { from = st; }
            else if (i == 2) { to = st; }
            else type = Integer.parseInt(st);
            i++;
        }
    }
}